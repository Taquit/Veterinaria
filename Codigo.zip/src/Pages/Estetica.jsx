import React from "react";

function Estetica(){

    return(

        <>
            <h1>Estetica</h1>
        </>
    )
}

export default Estetica